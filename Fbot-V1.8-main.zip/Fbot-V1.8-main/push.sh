git add . && git commit -m "termux push fixing commands" && git push 

